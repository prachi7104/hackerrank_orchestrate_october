# Agent trace bundle

Raw session files for HackerRank Orchestrate October 2026 (Ghost Data Still Exists).

- `claude-code/`: every Claude Code session for this challenge, including the 23 Oct planning session 989d84d9.
- `codex/`: every Codex rollout under ~/.codex/sessions/2026/10/23-25 that mentions this challenge.

Changes made to these copies only (originals kept locally, unchanged):

- 173 participant email addresses and key-shaped strings replaced with [REDACTED_EMAIL] / [REDACTED_SECRET].
- 177 embedded base64 image payloads (36,821,762 characters) replaced with a placeholder giving the payload length and SHA-256, so the bundle fits one 50 MB upload. The images are dataset evidence screenshots and browser captures; all text, tool calls and model output are unchanged.
